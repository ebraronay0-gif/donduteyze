import { useEffect, useState, useRef } from 'react';
import { Coins, Plus, LogIn, LogOut, User } from 'lucide-react';
import { getCredits } from '@/lib/credits';
import type { NavTabId } from '@/lib/navTabs';
import type { AuthUser } from '@/lib/auth';

interface CreditHeaderProps {
  onNavigate: (tab: NavTabId) => void;
  onAdminAccess?: () => void;
  authUser?: AuthUser | null;
  onAuthClick?: () => void;
  onSignOut?: () => void;
}

function CreditHeader({ onNavigate, onAdminAccess, authUser, onAuthClick, onSignOut }: CreditHeaderProps) {
  const [credits, setCredits] = useState<number>(() => getCredits());
  const tapCountRef = useRef(0);
  const tapTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const handler = () => setCredits(getCredits());
    window.addEventListener('credits-updated', handler);
    const interval = setInterval(handler, 1000);
    return () => {
      window.removeEventListener('credits-updated', handler);
      clearInterval(interval);
    };
  }, []);

  const handleLogoTap = () => {
    if (!onAdminAccess) return;
    tapCountRef.current += 1;
    if (tapTimerRef.current) window.clearTimeout(tapTimerRef.current);
    tapTimerRef.current = window.setTimeout(() => {
      tapCountRef.current = 0;
    }, 5000);
    if (tapCountRef.current >= 20) {
      tapCountRef.current = 0;
      onAdminAccess();
    }
  };

  return (
    <div className="sticky top-0 z-40 flex items-center justify-between border-b border-mystic-800/40 bg-night-900/80 px-4 py-3 backdrop-blur-xl">
      <div className="flex items-center gap-2">
        <button
          onClick={handleLogoTap}
          className="flex h-7 w-7 items-center justify-center rounded-full border border-gold-400/30 bg-gold-900/20"
          aria-label="kredi"
        >
          <Coins className="h-4 w-4 text-gold-300" />
        </button>
        <div className="flex items-baseline gap-1.5">
          <span className="font-display text-lg font-semibold text-gold-200">{credits}</span>
          <span className="text-xs text-mystic-400">kredi</span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {authUser ? (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 rounded-full border border-mystic-700/40 bg-night-700/40 px-2.5 py-1.5">
              <User className="h-3.5 w-3.5 text-mystic-300" />
              <span className="max-w-[100px] truncate text-xs text-mystic-200">{authUser.email}</span>
            </div>
            {onSignOut && (
              <button
                onClick={onSignOut}
                className="flex items-center gap-1 rounded-full border border-mystic-700/40 bg-night-700/40 px-2.5 py-1.5 text-xs text-mystic-300 transition hover:text-rose-300"
                aria-label="Çıkış"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        ) : (
          onAuthClick && (
            <button
              onClick={onAuthClick}
              className="flex items-center gap-1.5 rounded-full border border-gold-400/40 bg-gradient-to-r from-gold-700/20 to-gold-900/20 px-3 py-1.5 text-xs font-medium text-gold-200 transition hover:from-gold-600/30 hover:to-gold-800/30"
            >
              <LogIn className="h-3.5 w-3.5" />
              Üye Ol / Giriş
            </button>
          )
        )}

        <button
          onClick={() => onNavigate('premium')}
          className="group flex items-center gap-1.5 rounded-full border border-gold-400/40 bg-gradient-to-r from-gold-700/20 to-gold-900/20 px-3 py-1.5 text-xs font-medium text-gold-200 transition hover:from-gold-600/30 hover:to-gold-800/30 glow-border-gold"
        >
          <Plus className="h-3.5 w-3.5" />
          Kredi Al
        </button>
      </div>
    </div>
  );
}

export default CreditHeader;
