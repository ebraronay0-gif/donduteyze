import { useState } from 'react';
import { X, Headphones, Send, MessageCircle } from 'lucide-react';

interface SupportModalProps {
  open: boolean;
  onClose: () => void;
}

interface ChatMessage {
  id: number;
  sender: 'user' | 'support';
  text: string;
}

let messageIdCounter = 0;

function SupportModal({ open, onClose }: SupportModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: messageIdCounter++,
      sender: 'support',
      text: 'Merhaba! Döndü Teyze Canlı Destek hattına hoş geldiniz. Size nasıl yardımcı olabilirim?',
    },
  ]);
  const [input, setInput] = useState('');

  if (!open) return null;

  function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    const userMsg: ChatMessage = {
      id: messageIdCounter++,
      sender: 'user',
      text: input.trim(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');

    setTimeout(() => {
      const reply: ChatMessage = {
        id: messageIdCounter++,
        sender: 'support',
        text: 'Mesajınız alındı. Ekibimiz en kısa sürede size geri dönüş yapacak. Sabrınız için teşekkür ederiz!',
      };
      setMessages((prev) => [...prev, reply]);
    }, 1200);
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center sm:items-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-night-900/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative z-10 flex h-[70vh] w-full max-w-md flex-col overflow-hidden rounded-t-3xl border border-mystic-700/50 bg-night-800/95 shadow-2xl sm:rounded-3xl glow-border">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-mystic-800/50 px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-full border border-emerald-400/30 bg-emerald-900/20">
              <Headphones className="h-5 w-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-display text-base font-semibold text-mystic-100">
                Canlı Destek
              </h3>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs text-emerald-300">Çevrimiçi</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-mystic-400 transition hover:bg-mystic-800/40 hover:text-mystic-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm ${
                  msg.sender === 'user'
                    ? 'rounded-br-sm bg-gradient-to-br from-mystic-700 to-mystic-900 text-mystic-100'
                    : 'rounded-bl-sm border border-mystic-700/40 bg-night-700/60 text-mystic-200'
                }`}
              >
                {msg.sender === 'support' && (
                  <div className="mb-1 flex items-center gap-1">
                    <MessageCircle className="h-3 w-3 text-emerald-400" />
                    <span className="text-[10px] font-medium text-emerald-300">Destek</span>
                  </div>
                )}
                <p className="leading-relaxed">{msg.text}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <form
          onSubmit={handleSend}
          className="flex items-center gap-2 border-t border-mystic-800/50 px-4 py-3"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Mesajınızı yazın..."
            className="flex-1 rounded-xl border border-mystic-700/50 bg-night-700/60 px-3.5 py-2.5 text-sm text-mystic-100 placeholder-mystic-400/50 outline-none transition focus:border-emerald-400/50"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl border border-emerald-400/40 bg-emerald-600/20 text-emerald-300 transition hover:bg-emerald-600/30 disabled:opacity-40"
          >
            <Send className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  );
}

export default SupportModal;
