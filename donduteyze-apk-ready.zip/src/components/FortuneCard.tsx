import type { FortuneCategory } from '@/lib/fortuneCategories';

interface FortuneCardProps {
  category: FortuneCategory;
  onClick?: () => void;
}

function FortuneCard({ category, onClick }: FortuneCardProps) {
  const Icon = category.icon;

  return (
    <button
      onClick={onClick}
      className="group relative aspect-square overflow-hidden rounded-2xl border border-mystic-700/40 bg-gradient-to-br from-night-700/80 to-night-900/90 p-4 text-left transition-all duration-300 hover:scale-[1.03] hover:border-gold-400/50"
      style={{ boxShadow: `0 4px 20px ${category.glow}` }}
    >
      {/* Glow blob */}
      <div
        className="pointer-events-none absolute -top-8 -right-8 h-24 w-24 rounded-full opacity-30 blur-2xl transition-opacity duration-300 group-hover:opacity-60"
        style={{ backgroundColor: category.glow }}
      />

      {/* 3D Icon */}
      <div className="relative flex h-full flex-col items-center justify-center gap-3">
        <div
          className="relative transition-transform duration-500 group-hover:scale-110"
          style={{ perspective: '600px' }}
        >
          <div
            className="transition-transform duration-500 group-hover:[transform:rotateY(15deg)_rotateX(-10deg)]"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div
              className="flex h-16 w-16 items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-transparent backdrop-blur-sm"
              style={{
                boxShadow: `0 8px 24px ${category.glow}, inset 0 1px 1px rgba(255,255,255,0.15)`,
              }}
            >
              <Icon className={`h-8 w-8 ${category.iconColor}`} strokeWidth={1.5} />
            </div>
          </div>
        </div>

        <div className="text-center">
          <h3 className="font-display text-base font-semibold text-mystic-100">
            {category.name}
          </h3>
          <p className="mt-0.5 text-xs text-mystic-400">{category.description}</p>
        </div>
      </div>

      {/* Shimmer sweep */}
      <div className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/5 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
    </button>
  );
}

export default FortuneCard;
