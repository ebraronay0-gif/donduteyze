import type { ZodiacSign } from './profile';

export interface DailyHoroscope {
  general: string;
  love: string;
  career: string;
  luckyNumber: number;
  luckyColor: string;
}

const HOROSCOPES: Record<ZodiacSign, string[]> = {
  'Koç': [
    'Bugün cesaretin seni yeni fırsatlara taşıyacak. İçindeki ateşi kontrol et, sakin kal.',
    'Liderlik enerjin yüksek. Çevrendekiler seni takip edecek, yönünü iyi seç.',
    'Beklenmedik bir haber kapını çalabilir. Açık ol, korkma.',
  ],
  'Boğa': [
    'Sabır bugün en büyük gücün. Acele etme, meyveler zamanla olgunlaşacak.',
    'Maddi konularda dikkatli ol. Harcamalarını dengele, güvenli limanda kal.',
    'Sevdiğinle geçireceğin anlar huzur getirecek. Doğanın tadını çıkar.',
  ],
  'İkizler': [
    'İletişim becerin parlıyor. Yeni tanışmalar kapı açabilir, kulaklarını açık tut.',
    'Zihnin hızlı çalışıyor, fikirlerini kağıda dök. En iyi projeler bugün doğabilir.',
    'Kararsızlık seni yavaşlatmasın. İç sesini dinle ve ilk adımı at.',
  ],
  'Yengeç': [
    'Duyguların yoğun, sevdiklerine zaman ayır. Şefkat bugün en büyük hazinen.',
    'Evin ve ailenin seni bekliyor. İç huzuru dışarıda değil içeride ara.',
    'Geçmiş bir hatıra zihnine üşüşebilir. Affet ve serbest bırak.',
  ],
  'Aslan': [
    'Kendine güvenin tam. Sahne senin, parlamaya hazır ol ama tevazuyu elden bırakma.',
    'Yaratıcılığın zirvede. Sanatsal veya kişisel projelerde başarı kaçınılmaz.',
    'Takdir göreceğin bir gün. Gururlan ama kalbin sıcak kalsın.',
  ],
  'Başak': [
    'Detaylar senin gücün. Plan yap, düzenle ve düzenin getireceği huzuru hisset.',
    'Sağlığına dikkat et, bedenin senin tapınağın. Bugün kendine zaman ver.',
    'Eleştirel yanını kendine değil, projelene yönlendir. Mükemmellik zaman alır.',
  ],
  'Terazi': [
    'Denge ve uyum seni bekliyor. Çatışmalardan uzak dur, barışı seç.',
    'Estetik ve güzellik bugün seni etkiliyor. Sanatla iç içe ol.',
    'İkili ilişkilerde uyum yüksek. Sevdiğinle bir karar verme zamanı.',
  ],
  'Akrep': [
    'Sezgilerin keskin. Gizemli kapılar aralanıyor, karanlığın içinde ışığı bul.',
    'Dönüşüm zamanı. Eskiyi bırak, yeniden doğuş seni bekliyor.',
    'Tutkuların yoğun, enerjini doğru yöne kanalize et.',
  ],
  'Yay': [
    'Macera ruhu çağırıyor. Yeni ufuklar keşfet, sınırlarını aş.',
    'Öğrenme arzun yüksek. Bugün okuduğun veya duyduğun bir şey ufuk açacak.',
    'Optimizm seni taşıyacak. Gülümse, evren seninle.',
  ],
  'Oğlak': [
    'Hırsın ve disiplinin zirvede. Kariyerinde bir adım atabilirsin, fırsatı kaçırma.',
    'Sorumlulukların ağır ama omuzların güçlü. Sabırla ilerle.',
    'Uzun vadeli planlar bugün şekillenebilir. Temeli sağlam at.',
  ],
  'Kova': [
    'Özgünlüğün parlıyor. Sıradışı fikirlerin bugün takdir görecek.',
    'Sosyal çevin genişliyor. Yeni bir topluluk veya grup seni bekliyor.',
    'İnsancıl yanın ön planda. Birine yardım etmek ruhunu besleyecek.',
  ],
  'Balık': [
    'Hayal gücün sınırsız. Sanatla, müzikle veya yazıyla içini dök.',
    'Sezgilerin çok güçlü, kalbinin sesini dinle. Rüyalar mesaj taşıyabilir.',
    'Şefkatinle birine dokunabilirsin. Empatin en büyük gücün.',
  ],
};

const LUCKY_COLORS = [
  'Altın Sarı',
  'Gümüş',
  'Kırmızı',
  'Lacivert',
  'Yeşil',
  'Mor',
  'Turkuaz',
  'Bordo',
  'Pembe',
  'Beyaz',
];

function seededRandom(seed: number): number {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function getDayOfYear(date: Date): number {
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

export function getDailyHoroscope(zodiac: ZodiacSign): DailyHoroscope {
  const today = new Date();
  const dayOfYear = getDayOfYear(today);
  const year = today.getFullYear();

  const messages = HOROSCOPES[zodiac];
  const messageIndex = Math.floor(seededRandom(dayOfYear + year) * messages.length);
  const general = messages[messageIndex];

  const loveIndex = Math.floor(seededRandom(dayOfYear + year + 100) * messages.length);
  const love = messages[loveIndex];

  const careerIndex = Math.floor(seededRandom(dayOfYear + year + 200) * messages.length);
  const career = messages[careerIndex];

  const luckyNumber = Math.floor(seededRandom(dayOfYear + year + 300) * 99) + 1;
  const colorIndex = Math.floor(seededRandom(dayOfYear + year + 400) * LUCKY_COLORS.length);
  const luckyColor = LUCKY_COLORS[colorIndex];

  return { general, love, career, luckyNumber, luckyColor };
}
