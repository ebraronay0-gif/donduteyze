const WHEEL_KEY = 'fal_wheel_play_date';

function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function hasPlayedWheelToday(): boolean {
  try {
    return localStorage.getItem(WHEEL_KEY) === todayKey();
  } catch {
    return false;
  }
}

export function markWheelPlayed(): void {
  try {
    localStorage.setItem(WHEEL_KEY, todayKey());
  } catch {
    // ignore
  }
}
