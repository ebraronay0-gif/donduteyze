import { useState, useEffect, useCallback } from 'react';
import { Plus, Trash2, Save, Check, DollarSign, Sparkles } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const PRICE_KEYS = [
  { key: 'price_weekly', label: 'Haftalık Paket (TL)' },
  { key: 'price_monthly', label: 'Aylık Paket (TL)' },
  { key: 'price_yearly', label: 'Yıllık Paket (TL)' },
  { key: 'price_credits500', label: '500 Kredi Paketi (TL)' },
  { key: 'ticket_cost', label: 'Çekiliş Bilet Bedeli (Kredi)' },
  { key: 'lottery_prize', label: 'Çekiliş Ödülü (Kredi)' },
];

const CATEGORIES = [
  { id: 'love', label: 'Aşk', color: 'text-rose-300', border: 'border-rose-400/30', bg: 'bg-rose-900/10' },
  { id: 'career', label: 'Kariyer', color: 'text-sky-300', border: 'border-sky-400/30', bg: 'bg-sky-900/10' },
  { id: 'health', label: 'Sağlık', color: 'text-emerald-300', border: 'border-emerald-400/30', bg: 'bg-emerald-900/10' },
] as const;

function ContentPricing() {
  const [prices, setPrices] = useState<Record<string, string>>({});
  const [priceSaved, setPriceSaved] = useState(false);
  const [pool, setPool] = useState<{ id: string; category: string; message: string }[]>([]);
  const [newMessages, setNewMessages] = useState<Record<string, string>>({ love: '', career: '', health: '' });
  const [poolSaved, setPoolSaved] = useState(false);

  const fetchPrices = useCallback(async () => {
    try {
      const { data } = await supabase.from('app_config').select('key, value').in('key', PRICE_KEYS.map((p) => p.key));
      if (data) {
        const map: Record<string, string> = {};
        data.forEach((row: { key: string; value: string | null }) => { map[row.key] = row.value || ''; });
        setPrices(map);
      }
    } catch { /* ignore */ }
  }, []);

  const fetchPool = useCallback(async () => {
    try {
      const { data } = await supabase.from('horoscope_pool').select('*').order('category, created_at');
      if (data) setPool(data as { id: string; category: string; message: string }[]);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => { fetchPrices(); fetchPool(); }, [fetchPrices, fetchPool]);

  const handleSavePrice = async () => {
    try {
      const updates = PRICE_KEYS.map((p) =>
        supabase.from('app_config').update({ value: prices[p.key] || '', updated_at: new Date().toISOString() }).eq('key', p.key)
      );
      await Promise.all(updates);
      setPriceSaved(true);
      setTimeout(() => setPriceSaved(false), 2000);
    } catch { /* ignore */ }
  };

  const handleAddMessage = async (category: string) => {
    const msg = newMessages[category].trim();
    if (!msg) return;
    try {
      const { data } = await supabase.from('horoscope_pool').insert({ category, message: msg }).select().maybeSingle();
      if (data) {
        setPool((prev) => [...prev, data as { id: string; category: string; message: string }]);
        setNewMessages((prev) => ({ ...prev, [category]: '' }));
        setPoolSaved(true);
        setTimeout(() => setPoolSaved(false), 2000);
      }
    } catch { /* ignore */ }
  };

  const handleDeleteMessage = async (id: string) => {
    try {
      await supabase.from('horoscope_pool').delete().eq('id', id);
      setPool((prev) => prev.filter((m) => m.id !== id));
    } catch { /* ignore */ }
  };

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-bold text-mystic-100">İçerik & Fiyat Yönetimi</h1>
      <p className="mb-6 text-sm text-mystic-400">Fiyatları ve burç yorum havuzunu düzenleyin</p>

      {/* Pricing section */}
      <div className="mb-8 rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5">
        <div className="mb-4 flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-gold-300" />
          <h2 className="font-display text-lg font-semibold text-mystic-100">Fiyat Ayarları</h2>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {PRICE_KEYS.map((p) => (
            <div key={p.key}>
              <label className="mb-1 block text-xs text-mystic-300">{p.label}</label>
              <input
                type="text"
                value={prices[p.key] || ''}
                onChange={(e) => setPrices((prev) => ({ ...prev, [p.key]: e.target.value }))}
                className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50"
              />
            </div>
          ))}
        </div>
        <button
          onClick={handleSavePrice}
          className="mt-4 flex items-center gap-2 rounded-xl border border-gold-400/50 bg-gradient-to-r from-gold-700 to-gold-800 px-4 py-2.5 text-sm font-semibold text-gold-100 transition hover:scale-[1.02]"
        >
          {priceSaved ? <><Check className="h-4 w-4" /> Kaydedildi</> : <><Save className="h-4 w-4" /> Fiyatları Kaydet</>}
        </button>
      </div>

      {/* Horoscope pool section */}
      <div className="rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5">
        <div className="mb-4 flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-mystic-300" />
          <h2 className="font-display text-lg font-semibold text-mystic-100">Burç Yorum Havuzu</h2>
          {poolSaved && <span className="flex items-center gap-1 text-xs text-emerald-300"><Check className="h-3 w-3" /> Eklendi</span>}
        </div>

        <div className="space-y-6">
          {CATEGORIES.map((cat) => {
            const items = pool.filter((m) => m.category === cat.id);
            return (
              <div key={cat.id}>
                <h3 className={`mb-2 text-sm font-semibold ${cat.color}`}>{cat.label} Yorumları ({items.length})</h3>
                <div className="mb-2 flex gap-2">
                  <input
                    type="text"
                    value={newMessages[cat.id]}
                    onChange={(e) => setNewMessages((prev) => ({ ...prev, [cat.id]: e.target.value }))}
                    placeholder="Yeni yorum ekle..."
                    className="flex-1 rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2 text-sm text-mystic-100 outline-none focus:border-gold-400/50"
                  />
                  <button
                    onClick={() => handleAddMessage(cat.id)}
                    className="flex items-center gap-1 rounded-xl border border-emerald-400/40 bg-emerald-900/20 px-3 py-2 text-sm text-emerald-200 transition hover:bg-emerald-900/40"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <div className={`max-h-48 space-y-2 overflow-y-auto rounded-xl border ${cat.border} ${cat.bg} p-3`}>
                  {items.length === 0 ? (
                    <p className="text-center text-xs text-mystic-500">Henüz yorum yok</p>
                  ) : (
                    items.map((item) => (
                      <div key={item.id} className="flex items-start justify-between gap-2 rounded-lg bg-night-900/40 px-3 py-2">
                        <p className="text-xs leading-relaxed text-mystic-200">{item.message}</p>
                        <button onClick={() => handleDeleteMessage(item.id)} className="shrink-0 text-rose-400 hover:text-rose-300">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default ContentPricing;
