import { useState, useEffect, useCallback } from 'react';
import { Send, MessageCircle, Search } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface SupportMsg {
  id: string;
  user_id: string | null;
  user_email: string | null;
  sender: string;
  message: string;
  read: boolean;
  created_at: string;
}

function SupportChat() {
  const [messages, setMessages] = useState<SupportMsg[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEmail, setSelectedEmail] = useState<string | null>(null);
  const [reply, setReply] = useState('');
  const [search, setSearch] = useState('');
  const [sending, setSending] = useState(false);

  const fetchMessages = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('support_messages')
        .select('*')
        .order('created_at', { ascending: true });
      if (!error && data) setMessages(data as SupportMsg[]);
    } catch { /* ignore */ }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 5000);
    return () => clearInterval(interval);
  }, [fetchMessages]);

  // Group by user email
  const conversations = messages.reduce((acc, msg) => {
    const key = msg.user_email || 'Bilinmeyen';
    if (!acc[key]) acc[key] = [];
    acc[key].push(msg);
    return acc;
  }, {} as Record<string, SupportMsg[]>);

  const conversationList = Object.keys(conversations).filter((email) =>
    email.toLowerCase().includes(search.toLowerCase())
  );

  const selectedMessages = selectedEmail ? conversations[selectedEmail] || [] : [];

  const handleSend = async () => {
    if (!reply.trim() || !selectedEmail || sending) return;
    setSending(true);
    try {
      const userMsgs = conversations[selectedEmail];
      const userId = userMsgs?.[0]?.user_id || null;
      const { data } = await supabase
        .from('support_messages')
        .insert({
          user_id: userId,
          user_email: selectedEmail,
          sender: 'admin',
          message: reply.trim(),
          read: true,
        })
        .select()
        .maybeSingle();
      if (data) {
        setMessages((prev) => [...prev, data as SupportMsg]);
        setReply('');
      }
    } catch { /* ignore */ }
    setSending(false);
  };

  if (loading) {
    return <div className="flex h-64 items-center justify-center"><span className="h-8 w-8 animate-spin rounded-full border-2 border-gold-400/30 border-t-gold-400" /></div>;
  }

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-bold text-mystic-100">Canlı Destek</h1>
      <p className="mb-6 text-sm text-mystic-400">Kullanıcı mesajlarını görüntüleyin ve yanıtlayın</p>

      <div className="flex h-[calc(100vh-200px)] min-h-[400px] gap-4">
        {/* Conversation list */}
        <div className="w-64 shrink-0 overflow-y-auto rounded-2xl border border-mystic-700/40 bg-night-800/60">
          <div className="border-b border-mystic-700/40 p-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-mystic-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Ara..."
                className="w-full rounded-lg border border-mystic-700/50 bg-night-900/60 py-2 pl-8 pr-2 text-xs text-mystic-100 outline-none focus:border-gold-400/50"
              />
            </div>
          </div>
          <div className="space-y-1 p-2">
            {conversationList.length === 0 ? (
              <p className="p-4 text-center text-xs text-mystic-500">Konuşma yok</p>
            ) : (
              conversationList.map((email) => {
                const msgs = conversations[email];
                const lastMsg = msgs[msgs.length - 1];
                const hasUnread = msgs.some((m) => m.sender === 'user' && !m.read);
                return (
                  <button
                    key={email}
                    onClick={() => setSelectedEmail(email)}
                    className={`block w-full rounded-lg px-3 py-2.5 text-left transition ${
                      selectedEmail === email ? 'bg-gold-900/30 border border-gold-400/30' : 'hover:bg-night-700/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="truncate text-xs font-medium text-mystic-100">{email}</span>
                      {hasUnread && <span className="h-2 w-2 shrink-0 rounded-full bg-rose-400" />}
                    </div>
                    <p className="mt-0.5 truncate text-[10px] text-mystic-400">{lastMsg?.message}</p>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Chat area */}
        <div className="flex flex-1 flex-col overflow-hidden rounded-2xl border border-mystic-700/40 bg-night-800/60">
          {selectedEmail ? (
            <>
              <div className="border-b border-mystic-700/40 px-4 py-3">
                <div className="flex items-center gap-2">
                  <MessageCircle className="h-4 w-4 text-gold-300" />
                  <span className="font-display text-sm font-semibold text-mystic-100">{selectedEmail}</span>
                </div>
              </div>
              <div className="flex-1 space-y-3 overflow-y-auto p-4">
                {selectedMessages.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.sender === 'admin' ? 'justify-end' : 'justify-start'}`}>
                    <div
                      className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
                        msg.sender === 'admin'
                          ? 'bg-gradient-to-r from-gold-700 to-gold-800 text-gold-100'
                          : 'bg-night-700/60 text-mystic-100'
                      }`}
                    >
                      <p className="leading-relaxed">{msg.message}</p>
                      <p className="mt-1 text-[10px] opacity-60">
                        {new Date(msg.created_at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t border-mystic-700/40 p-3">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Yanıt yazın..."
                    className="flex-1 rounded-xl border border-mystic-700/50 bg-night-900/60 px-4 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50"
                  />
                  <button
                    onClick={handleSend}
                    disabled={sending || !reply.trim()}
                    className="flex items-center justify-center rounded-xl border border-gold-400/50 bg-gradient-to-r from-gold-700 to-gold-800 px-4 text-gold-100 transition hover:scale-105 disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-1 items-center justify-center text-center">
              <div>
                <MessageCircle className="mx-auto mb-3 h-10 w-10 text-mystic-600" />
                <p className="text-sm text-mystic-400">Bir konuşma seçin</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default SupportChat;
