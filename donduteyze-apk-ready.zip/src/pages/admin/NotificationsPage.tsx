import { useState, useEffect, useCallback } from 'react';
import { Bell, Send, Check, Users, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Notification {
  id: string;
  title: string;
  body: string | null;
  target: string;
  target_user_id: string | null;
  created_at: string;
}

interface AppUser {
  id: string;
  email: string;
  full_name: string | null;
}

function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [users, setUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [target, setTarget] = useState<'all' | 'user'>('all');
  const [selectedUserId, setSelectedUserId] = useState('');
  const [sent, setSent] = useState(false);

  const fetchNotifications = useCallback(async () => {
    try {
      const { data } = await supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50);
      if (data) setNotifications(data as Notification[]);
    } catch { /* ignore */ }
  }, []);

  const fetchUsers = useCallback(async () => {
    try {
      const { data } = await supabase.from('app_users').select('id, email, full_name').order('email');
      if (data) setUsers(data as AppUser[]);
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    (async () => {
      await Promise.all([fetchNotifications(), fetchUsers()]);
      setLoading(false);
    })();
  }, [fetchNotifications, fetchUsers]);

  const handleSend = async () => {
    if (!title.trim()) return;
    try {
      const insertData: { title: string; body: string | null; target: string; target_user_id?: string } = {
        title: title.trim(),
        body: body.trim() || null,
        target,
      };
      if (target === 'user' && selectedUserId) {
        insertData.target_user_id = selectedUserId;
      }
      const { data } = await supabase.from('notifications').insert(insertData).select().maybeSingle();
      if (data) {
        setNotifications((prev) => [data as Notification, ...prev]);
        setTitle('');
        setBody('');
        setSelectedUserId('');
        setTarget('all');
        setSent(true);
        setTimeout(() => setSent(false), 2500);
      }
    } catch { /* ignore */ }
  };

  return (
    <div>
      <h1 className="mb-1 font-display text-2xl font-bold text-mystic-100">Bildirim Gönder</h1>
      <p className="mb-6 text-sm text-mystic-400">Kullanıcılara anlık bildirim ve duyuru gönderin</p>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Compose */}
        <div className="rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5">
          <div className="mb-4 flex items-center gap-2">
            <Bell className="h-5 w-5 text-gold-300" />
            <h2 className="font-display text-lg font-semibold text-mystic-100">Yeni Bildirim</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-xs text-mystic-300">Başlık *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Bildirim başlığı"
                className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs text-mystic-300">İçerik</label>
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Bildirim metni"
                rows={4}
                className="w-full resize-none rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50"
              />
            </div>
            <div>
              <label className="mb-2 block text-xs text-mystic-300">Hedef Kitle</label>
              <div className="flex gap-2">
                <button
                  onClick={() => setTarget('all')}
                  className={`flex flex-1 items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm transition ${
                    target === 'all'
                      ? 'border-gold-400/50 bg-gold-900/30 text-gold-200'
                      : 'border-mystic-700/40 bg-night-900/40 text-mystic-300'
                  }`}
                >
                  <Users className="h-4 w-4" /> Tüm Kullanıcılar
                </button>
                <button
                  onClick={() => setTarget('user')}
                  className={`flex flex-1 items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm transition ${
                    target === 'user'
                      ? 'border-gold-400/50 bg-gold-900/30 text-gold-200'
                      : 'border-mystic-700/40 bg-night-900/40 text-mystic-300'
                  }`}
                >
                  <User className="h-4 w-4" /> Belirli Kullanıcı
                </button>
              </div>
            </div>
            {target === 'user' && (
              <div>
                <label className="mb-1 block text-xs text-mystic-300">Kullanıcı Seç</label>
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="w-full rounded-xl border border-mystic-700/50 bg-night-900/60 px-3 py-2.5 text-sm text-mystic-100 outline-none focus:border-gold-400/50"
                >
                  <option value="">Seçiniz...</option>
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>{u.email}</option>
                  ))}
                </select>
              </div>
            )}
            <button
              onClick={handleSend}
              disabled={!title.trim() || (target === 'user' && !selectedUserId)}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-gold-400/50 bg-gradient-to-r from-gold-700 to-gold-800 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:scale-[1.02] disabled:opacity-50"
            >
              {sent ? <><Check className="h-4 w-4" /> Gönderildi</> : <><Send className="h-4 w-4" /> Bildirim Gönder</>}
            </button>
          </div>
        </div>

        {/* History */}
        <div className="rounded-2xl border border-mystic-700/40 bg-night-800/60 p-5">
          <h2 className="mb-4 font-display text-lg font-semibold text-mystic-100">Gönderilen Bildirimler</h2>
          {loading ? (
            <div className="flex h-32 items-center justify-center"><span className="h-6 w-6 animate-spin rounded-full border-2 border-gold-400/30 border-t-gold-400" /></div>
          ) : (
            <div className="max-h-96 space-y-3 overflow-y-auto">
              {notifications.length === 0 ? (
                <p className="py-8 text-center text-sm text-mystic-500">Henüz bildirim gönderilmedi</p>
              ) : (
                notifications.map((notif) => (
                  <div key={notif.id} className="rounded-xl border border-mystic-700/30 bg-night-700/40 p-3">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-semibold text-mystic-100">{notif.title}</h3>
                      <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] ${
                        notif.target === 'all' ? 'bg-sky-900/30 text-sky-300' : 'bg-rose-900/30 text-rose-300'
                      }`}>
                        {notif.target === 'all' ? 'Tümü' : 'Bireysel'}
                      </span>
                    </div>
                    {notif.body && <p className="mt-1 text-xs leading-relaxed text-mystic-300">{notif.body}</p>}
                    <p className="mt-2 text-[10px] text-mystic-500">
                      {new Date(notif.created_at).toLocaleString('tr-TR')}
                    </p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default NotificationsPage;
