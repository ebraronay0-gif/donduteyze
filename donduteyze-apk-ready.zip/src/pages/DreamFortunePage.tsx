import { useState, useCallback } from 'react';
import { ArrowLeft, Moon, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import type { NavTabId } from '@/lib/navTabs';
import { submitFortune } from '@/lib/fortuneApi';

interface DreamFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

function DreamFortunePage({ onNavigate }: DreamFortunePageProps) {
  const [dream, setDream] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAd, setShowAd] = useState(false);

  const canSubmit = dream.trim().length > 0;

  const handleSubmit = useCallback(async () => {
    if (!canSubmit || submitting) return;
    setShowAd(true);
  }, [canSubmit, submitting]);

  const handleAdComplete = useCallback(async () => {
    setShowAd(false);
    setSubmitting(true);
    setError(null);
    
    try {
      // Yapay zeka fal/rüya API'sine rüya metnini gönderiyoruz
      const result = await submitFortune({
        fortuneType: 'dream',
        userInput: dream,
      });

      if (result.success) {
        setSubmitting(false);
        setSuccess(true);
        setTimeout(() => {
          onNavigate('history');
        }, 3000);
      } else {
        setSubmitting(false);
        setError(result.error || 'Rüyanız yapay zeka tarafından yorumlanamadı.');
      }
    } catch (err) {
      setSubmitting(false);
      setError('Bir hata oluştu. Lütfen tekrar deneyin.');
    }
  }, [dream, onNavigate]);

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={60} />

      {/* Dreamy moonlit background */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-indigo-950/60 via-night-900/70 to-night-900/95" />
      <div className="pointer-events-none absolute top-10 right-8 h-40 w-40 rounded-full bg-indigo-300/10 blur-3xl" />
      <div className="pointer-events-none absolute bottom-20 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-indigo-700/15 blur-3xl" />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-indigo-600/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/2 -right-32 h-64 w-64 rounded-full bg-indigo-700/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-indigo-400/30 bg-indigo-900/20 text-indigo-200 transition hover:border-indigo-400/60 hover:text-indigo-100"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <Moon className="h-6 w-6 text-indigo-300" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Rüya Yorumlama</h1>
          </div>
        </div>

        {/* Intro card */}
        <div className="relative mb-8 overflow-hidden rounded-2xl border border-indigo-500/30 bg-gradient-to-br from-indigo-900/30 via-night-700/70 to-night-800/80 p-5 backdrop-blur-sm" style={{ boxShadow: '0 0 12px rgba(99, 102, 241, 0.25), 0 0 24px rgba(99, 102, 241, 0.15), inset 0 0 10px rgba(99, 102, 241, 0.08)' }}>
          <div className="pointer-events-none absolute -top-10 -right-10 h-32 w-32 rounded-full bg-indigo-500/20 blur-3xl" />
          <div className="relative flex items-start gap-3">
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-indigo-400/30 bg-indigo-900/30"
              style={{ boxShadow: '0 6px 18px rgba(99, 102, 241, 0.35), inset 0 1px 1px rgba(255,255,255,0.15)' }}
            >
              <Sparkles className="h-6 w-6 text-indigo-300" />
            </div>
            <div>
              <h2 className="font-display text-lg font-semibold text-indigo-100">Yapay Zeka ile Rüya Analizi</h2>
              <p className="mt-1 font-serif text-sm italic leading-relaxed text-indigo-100/80">
                Gördüğün rüyayı detaylıca anlat, yapay zeka tabanlı rüya tabircimiz rüyanın gizli mesajlarını ve anlamını analiz etsin.
              </p>
            </div>
          </div>
        </div>

        {/* Dream text area */}
        <div className="mb-6">
          <label className="mb-2 block font-display text-sm font-semibold text-indigo-100">Rüyanız</label>
          <div className="relative">
            <textarea
              value={dream}
              onChange={(e) => setDream(e.target.value)}
              disabled={submitting || success}
              rows={8}
              placeholder="Rüyanızda neler gördünüz? Detaylıca anlatın..."
              className="w-full resize-none rounded-[2rem] border border-indigo-500/30 bg-gradient-to-br from-night-700/80 to-night-900/90 px-6 py-5 font-serif text-base italic leading-relaxed text-indigo-50 placeholder:text-indigo-300/40 backdrop-blur-sm transition focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 disabled:cursor-not-allowed disabled:opacity-60"
              style={{ boxShadow: '0 4px 20px rgba(99, 102, 241, 0.15), inset 0 1px 1px rgba(255,255,255,0.05)' }}
            />
            <div className="pointer-events-none absolute -top-8 -right-8 h-24 w-24 rounded-full bg-indigo-500/15 blur-2xl" />
          </div>
          <p className="mt-2 text-right text-xs text-indigo-300/50">{dream.length} karakter</p>
        </div>

        {/* Submit button */}
        <button
          onClick={handleSubmit}
          disabled={!canSubmit || submitting || success}
          className="group relative mb-6 flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl border border-indigo-400/50 bg-gradient-to-r from-indigo-700 via-indigo-800 to-night-800 px-6 py-4 transition-all duration-300 enabled:hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50"
          style={{ boxShadow: '0 0 12px rgba(99, 102, 241, 0.3), 0 0 24px rgba(99, 102, 241, 0.2)' }}
        >
          <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-indigo-300/25 to-transparent transition-transform duration-1000 enabled:group-hover:translate-x-full" />
          {submitting ? (
            <>
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-indigo-200/30 border-t-indigo-200" />
              <span className="font-display text-lg font-semibold text-indigo-100">Yapay Zeka Rüyanızı Yorumluyor...</span>
            </>
          ) : success ? (
            <>
              <CheckCircle2 className="h-5 w-5 text-emerald-300" />
              <span className="font-display text-lg font-semibold text-emerald-200">Yorumlandı!</span>
            </>
          ) : (
            <>
              <Moon className="h-5 w-5 text-indigo-300" />
              <span className="font-display text-lg font-semibold text-indigo-100">Rüyamı Yorumla</span>
            </>
          )}
        </button>

        {error && (
          <div className="mb-4 flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-900/20 px-4 py-3 text-sm text-rose-200">
            <AlertCircle className="h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        {/* Legal disclaimer */}
        <p className="mx-auto max-w-md text-center text-[9px] leading-relaxed text-mystic-500/40">
          Döndü Teyze bir eğlence uygulamasıdır. Yapay zeka tarafından yapılan rüya yorumları yalnızca eğlence amaçlıdır.
        </p>
      </div>

      <RewardedAdModal
        open={showAd}
        onComplete={handleAdComplete}
        onClose={() => setShowAd(false)}
        rewardLabel="Rüya Yorumu"
      />

      {/* Success overlay */}
      {success && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in">
          <div className="relative max-w-sm rounded-2xl border border-indigo-400/40 bg-gradient-to-br from-indigo-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 12px rgba(99, 102, 241, 0.3), 0 0 24px rgba(99, 102, 241, 0.2)' }}>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-indigo-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div
                className="flex h-20 w-20 items-center justify-center rounded-full border border-indigo-400/40 bg-indigo-900/30"
                style={{ boxShadow: '0 0 36px rgba(99, 102, 241, 0.5)' }}
              >
                <CheckCircle2 className="h-10 w-10 text-indigo-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-indigo-100">Rüyanız Yorumlandı</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Yapay zeka rüyanızı başarıyla analiz etti. Geçmiş fallarım sayfasına yönlendiriliyorsunuz...
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default DreamFortunePage;
