import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Gamepad2, Coins, CheckCircle2, Info } from 'lucide-react';
import StarField from '@/components/StarField';
import RewardedAdModal from '@/components/RewardedAdModal';
import { addCredits } from '@/lib/credits';
import { hasPlayedWheelToday, markWheelPlayed } from '@/lib/wheel';
import type { NavTabId } from '@/lib/navTabs';

interface WheelFortunePageProps {
  onNavigate: (tab: NavTabId) => void;
}

const SEGMENTS = [
  { label: '1 Kredi', value: 1, color: '#7c3aed' },
  { label: '3 Kredi', value: 3, color: '#b45309' },
  { label: '2 Kredi', value: 2, color: '#0e7490' },
  { label: '5 Kredi', value: 5, color: '#be123c' },
  { label: '1 Kredi', value: 1, color: '#6d28d9' },
  { label: '4 Kredi', value: 4, color: '#92400e' },
  { label: '2 Kredi', value: 2, color: '#0891b2' },
  { label: '3 Kredi', value: 3, color: '#9f1239' },
];

const SEG_COUNT = SEGMENTS.length;
const SEG_ANGLE = 360 / SEG_COUNT;

function WheelFortunePage({ onNavigate }: WheelFortunePageProps) {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [played, setPlayed] = useState(() => hasPlayedWheelToday());
  const [showLimit, setShowLimit] = useState(false);
  const [result, setResult] = useState<{ value: number; label: string } | null>(null);
  const [pendingReward, setPendingReward] = useState<{ value: number; label: string } | null>(null);
  const spinTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (spinTimeout.current) clearTimeout(spinTimeout.current);
    };
  }, []);

  const handleSpin = () => {
    if (spinning) return;
    if (played) {
      setShowLimit(true);
      return;
    }
    setSpinning(true);
    setResult(null);

    const targetIndex = Math.floor(Math.random() * SEG_COUNT);
    const targetAngle = 360 * 5 + (SEG_COUNT * SEG_ANGLE - (targetIndex * SEG_ANGLE + SEG_ANGLE / 2));
    const newRotation = rotation + targetAngle;
    setRotation(newRotation);

    spinTimeout.current = setTimeout(() => {
      const seg = SEGMENTS[targetIndex];
      setSpinning(false);
      setPendingReward({ value: seg.value, label: seg.label });
    }, 4500);
  };

  const handleCloseResult = () => {
    setResult(null);
    onNavigate('home');
  };

  const handleAdComplete = () => {
    if (!pendingReward) return;
    addCredits(pendingReward.value);
    markWheelPlayed();
    setPlayed(true);
    setResult({ value: pendingReward.value, label: pendingReward.label });
    setPendingReward(null);
    window.dispatchEvent(new Event('credits-updated'));
  };

  const handleAdClose = () => {
    setPendingReward(null);
    onNavigate('home');
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-night-900 pb-28">
      <StarField count={50} />

      {/* Ambient glows */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-rose-600/20 animate-glow-pulse" />
      <div className="pointer-events-none absolute top-1/2 -right-32 h-64 w-64 rounded-full bg-amber-600/15 animate-glow-pulse" style={{ animationDelay: '2s' }} />

      <div className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-rose-400/30 bg-rose-900/20 text-rose-200 transition hover:border-rose-400/60 hover:text-rose-100"
          >
            <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <div className="flex items-center gap-2">
            <Gamepad2 className="h-6 w-6 text-rose-300" />
            <h1 className="font-display text-2xl font-semibold text-shimmer">Çarkıfelek</h1>
          </div>
        </div>

        {/* Intro card */}
        <div className="relative mb-8 overflow-hidden rounded-2xl border border-rose-500/30 bg-gradient-to-br from-rose-900/30 via-night-700/70 to-night-800/80 p-5 backdrop-blur-sm" style={{ boxShadow: '0 0 12px rgba(244, 63, 94, 0.25), 0 0 24px rgba(244, 63, 94, 0.15), inset 0 0 10px rgba(244, 63, 94, 0.08)' }}>
          <div className="pointer-events-none absolute -top-10 -right-10 h-32 w-32 rounded-full bg-rose-500/20 blur-3xl" />
          <div className="relative flex items-start gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-rose-400/30 bg-rose-900/30" style={{ boxShadow: '0 6px 18px rgba(244, 63, 94, 0.35), inset 0 1px 1px rgba(255,255,255,0.15)' }}>
              <Coins className="h-6 w-6 text-rose-300" />
            </div>
            <div>
              <h2 className="font-display text-lg font-semibold text-rose-100">Günlük Şans Çarkı</h2>
              <p className="mt-1 font-serif text-sm italic leading-relaxed text-rose-100/80">
                Çarkı çevir, kazandığın kredileri fal baktırmada kullan. Her gün bir kez oynayabilirsin.
              </p>
            </div>
          </div>
        </div>

        {/* Wheel */}
        <div className="mb-8 flex flex-col items-center">
          <div className="relative" style={{ width: '300px', height: '300px' }}>
            {/* Pointer */}
            <div className="absolute left-1/2 top-[-10px] z-20 h-0 w-0 -translate-x-1/2 border-l-[12px] border-r-[12px] border-t-[20px] border-l-transparent border-r-transparent border-t-gold-300 drop-shadow-lg" />

            {/* Outer ring */}
            <div className="absolute inset-0 rounded-full border-4 border-gold-400/40" style={{ boxShadow: '0 0 24px rgba(251, 191, 36, 0.3), inset 0 0 12px rgba(251, 191, 36, 0.15)' }} />

            {/* Spinning wheel */}
            <div
              className="absolute inset-0 rounded-full overflow-hidden"
              style={{
                transform: `rotate(${rotation}deg)`,
                transition: spinning ? 'transform 4.5s cubic-bezier(0.17, 0.67, 0.12, 0.99)' : 'none',
              }}
            >
              <svg viewBox="0 0 200 200" className="h-full w-full">
                {SEGMENTS.map((seg, i) => {
                  const startAngle = (i * SEG_ANGLE - 90) * (Math.PI / 180);
                  const endAngle = ((i + 1) * SEG_ANGLE - 90) * (Math.PI / 180);
                  const x1 = 100 + 100 * Math.cos(startAngle);
                  const y1 = 100 + 100 * Math.sin(startAngle);
                  const x2 = 100 + 100 * Math.cos(endAngle);
                  const y2 = 100 + 100 * Math.sin(endAngle);
                  const midAngle = (startAngle + endAngle) / 2;
                  const tx = 100 + 60 * Math.cos(midAngle);
                  const ty = 100 + 60 * Math.sin(midAngle);
                  const rotateDeg = (midAngle * 180) / Math.PI;
                  return (
                    <g key={i}>
                      <path
                        d={`M 100 100 L ${x1} ${y1} A 100 100 0 0 1 ${x2} ${y2} Z`}
                        fill={seg.color}
                        stroke="rgba(255,255,255,0.15)"
                        strokeWidth="0.5"
                      />
                      <text
                        x={tx}
                        y={ty}
                        fill="#fff"
                        fontSize="9"
                        fontWeight="700"
                        textAnchor="middle"
                        dominantBaseline="middle"
                        transform={`rotate(${rotateDeg} ${tx} ${ty})`}
                        style={{ fontFamily: 'Cinzel, serif' }}
                      >
                        {seg.value} K
                      </text>
                    </g>
                  );
                })}
                <circle cx="100" cy="100" r="14" fill="#1a1029" stroke="#fbbf24" strokeWidth="2" />
              </svg>
            </div>
          </div>

          {/* Spin button */}
          <button
            onClick={handleSpin}
            disabled={spinning || played}
            className="group relative mt-8 flex w-full max-w-xs items-center justify-center gap-2 overflow-hidden rounded-2xl border border-rose-400/50 bg-gradient-to-r from-rose-700 via-rose-800 to-night-800 px-6 py-4 transition-all duration-300 enabled:hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50"
            style={{ boxShadow: '0 0 12px rgba(244, 63, 94, 0.3), 0 0 24px rgba(244, 63, 94, 0.2)' }}
          >
            <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-rose-300/25 to-transparent transition-transform duration-1000 enabled:group-hover:translate-x-full" />
            {spinning ? (
              <>
                <span className="h-5 w-5 animate-spin rounded-full border-2 border-rose-200/30 border-t-rose-200" />
                <span className="font-display text-lg font-semibold text-rose-100">Çark dönüyor...</span>
              </>
            ) : played ? (
              <>
                <Info className="h-5 w-5 text-rose-300" />
                <span className="font-display text-lg font-semibold text-rose-100">Bugün oynadınız</span>
              </>
            ) : (
              <>
                <Gamepad2 className="h-5 w-5 text-rose-300" />
                <span className="font-display text-lg font-semibold text-rose-100">Çevir</span>
              </>
            )}
          </button>

          {played && !spinning && (
            <p className="mt-4 text-center text-sm text-mystic-400">
              Bugünkü hakkınızı kullandınız, yarın tekrar bekleriz.
            </p>
          )}
        </div>

        {/* Legal disclaimer */}
        <p className="mx-auto max-w-md text-center text-[9px] leading-relaxed text-mystic-500/40">
          Döndü Teyze bir eğlence uygulamasıdır. Çarkıfelek kredileri yalnızca uygulama içi kullanım içindir.
        </p>
      </div>

      {/* Daily limit modal */}
      {showLimit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in" onClick={() => setShowLimit(false)}>
          <div className="relative max-w-sm rounded-2xl border border-rose-400/40 bg-gradient-to-br from-rose-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 12px rgba(244, 63, 94, 0.3), 0 0 24px rgba(244, 63, 94, 0.2)' }} onClick={(e) => e.stopPropagation()}>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-rose-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full border border-rose-400/40 bg-rose-900/30" style={{ boxShadow: '0 0 36px rgba(244, 63, 94, 0.5)' }}>
                <Info className="h-10 w-10 text-rose-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-rose-100">Bugünkü Hakkınızı Kullandınız</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Çarkıfelek her gün yalnızca bir kez oynanabilir. Yarın tekrar bekleriz!
            </p>
            <button
              onClick={() => setShowLimit(false)}
              className="mt-6 w-full rounded-xl border border-rose-400/40 bg-rose-900/30 px-4 py-3 font-display text-sm font-semibold text-rose-100 transition hover:bg-rose-800/40"
            >
              Tamam
            </button>
          </div>
        </div>
      )}

      <RewardedAdModal
        open={pendingReward !== null}
        onComplete={handleAdComplete}
        onClose={handleAdClose}
        rewardLabel={`${pendingReward?.value ?? 0} Kredi`}
      />

      {/* Result modal */}
      {result && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 px-6 backdrop-blur-sm animate-fade-in">
          <div className="relative max-w-sm rounded-2xl border border-gold-400/40 bg-gradient-to-br from-gold-900/40 via-night-700/90 to-night-800/95 p-8 text-center animate-fade-in-up" style={{ boxShadow: '0 0 12px rgba(251, 191, 36, 0.3), 0 0 24px rgba(251, 191, 36, 0.2)' }}>
            <div className="pointer-events-none absolute -top-16 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full bg-gold-500/25 blur-3xl" />
            <div className="relative mb-5 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full border border-gold-400/40 bg-gold-900/30" style={{ boxShadow: '0 0 36px rgba(251, 191, 36, 0.5)' }}>
                <CheckCircle2 className="h-10 w-10 text-gold-300" />
              </div>
            </div>
            <h2 className="mb-2 font-display text-xl font-semibold text-gold-100">Tebrikler!</h2>
            <p className="font-serif text-base italic leading-relaxed text-mystic-200">
              Çarktan <span className="font-semibold text-gold-200">{result.value} kredi</span> kazandınız!
            </p>
            <button
              onClick={handleCloseResult}
              className="mt-6 w-full rounded-xl border border-gold-400/40 bg-gold-900/30 px-4 py-3 font-display text-sm font-semibold text-gold-100 transition hover:bg-gold-800/40"
            >
              Ana Sayfaya Dön
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default WheelFortunePage;
