# Döndü Teyze Android APK

Bu proje Capacitor 6 + Android + Vite kullanır.

## Telefonda test APK'sı

GitHub'a push ettikten sonra **Actions → Build Döndü Teyze Android APK → Run workflow** ile derlemeyi başlatabilirsiniz.

Build tamamlandığında **donduteyze-debug-apk** artifact'inden `app-debug.apk` indirilebilir.

Bu APK fiziksel Android telefonda test içindir. Google Play yayını için daha sonra imzalı **AAB** üretmeliyiz.

## İlk kurulum

Android telefonda bilinmeyen kaynaklardan uygulama yükleme izni gerekebilir. Google Play'den olmayan APK olduğu için Android bunu sorabilir.

## Önemli

- APK debug sürümüdür; mağaza yayını için kullanılmamalıdır.
- Gerçek AdMob reklamlarını test etmek yerine yayın öncesinde test reklamları kullanılmalıdır.
- Google/Apple OAuth için Supabase ve sağlayıcı tarafındaki redirect ayarları ayrıca yapılmalıdır.
