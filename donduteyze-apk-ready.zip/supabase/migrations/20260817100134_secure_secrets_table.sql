/*
# Secure Secrets Storage

A separate table for sensitive keys (like GEMINI_API_KEY) that is NOT readable by anon/authenticated roles.
Only the service role (used by edge functions) can access this table, since it bypasses RLS.

1. New Table
- `app_secrets`: Key-value store for sensitive API keys and secrets.
  - `key` (text, primary key)
  - `value` (text)
  - `updated_at` (timestamptz, default now())

2. Security
- RLS enabled but NO policies for anon/authenticated — they cannot read or write.
- Service role bypasses RLS, so edge functions can read freely.
*/

CREATE TABLE IF NOT EXISTS app_secrets (
  key text PRIMARY KEY,
  value text,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE app_secrets ENABLE ROW LEVEL SECURITY;

-- No policies: anon and authenticated cannot access this table.
-- Service role bypasses RLS automatically.

-- Remove the gemini_api_key from the publicly-readable app_config table.
DELETE FROM app_config WHERE key = 'gemini_api_key';

-- Insert into the secure table instead.
INSERT INTO app_secrets (key, value) VALUES
  ('gemini_api_key', 'AQ.Ab8RN6JVQjpt44lBxQsCoiycRYyQDfvUGGj5fvxSchjA9I9g_w')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now();