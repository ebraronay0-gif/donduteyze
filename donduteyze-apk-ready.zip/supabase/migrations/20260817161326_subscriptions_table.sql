/*
# Subscriptions table

1. New Tables
- `subscriptions`
  - `id` (uuid, primary key)
  - `user_email` (text, not null) — links to app_users by email
  - `plan` (text, not null) — 'weekly' | 'monthly' | 'yearly'
  - `ad_free` (boolean, default true) — whether ads are hidden
  - `daily_credits` (integer, default 20) — credits granted daily
  - `starts_at` (timestamptz, default now)
  - `expires_at` (timestamptz, not null) — when the subscription ends
  - `last_credit_grant` (timestamptz, nullable) — last time daily credits were given
  - `active` (boolean, default true)
  - `created_at` (timestamptz, default now)
2. Security
  - Enable RLS on `subscriptions`.
  - Authenticated users can read their own subscriptions (by email matching auth.jwt email).
  - Inserts via service role only (edge function).
3. Notes
  - The daily credit grant is performed by an edge function (cron-style) that checks
    `last_credit_grant` and grants `daily_credits` if a day has passed and the
    subscription is still active (expires_at > now).
*/

CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_email text NOT NULL,
  plan text NOT NULL CHECK (plan IN ('weekly', 'monthly', 'yearly')),
  ad_free boolean NOT NULL DEFAULT true,
  daily_credits integer NOT NULL DEFAULT 20,
  starts_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  last_credit_grant timestamptz,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user_email ON subscriptions(user_email);
CREATE INDEX IF NOT EXISTS idx_subscriptions_active ON subscriptions(active) WHERE active = true;

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_subscriptions" ON subscriptions;
CREATE POLICY "select_own_subscriptions"
ON subscriptions FOR SELECT
TO authenticated
USING (user_email = (auth.jwt() ->> 'email'));

DROP POLICY IF EXISTS "insert_own_subscriptions" ON subscriptions;
CREATE POLICY "insert_own_subscriptions"
ON subscriptions FOR INSERT
TO authenticated
WITH CHECK (user_email = (auth.jwt() ->> 'email'));

DROP POLICY IF EXISTS "update_own_subscriptions" ON subscriptions;
CREATE POLICY "update_own_subscriptions"
ON subscriptions FOR UPDATE
TO authenticated
USING (user_email = (auth.jwt() ->> 'email'))
WITH CHECK (user_email = (auth.jwt() ->> 'email'));
