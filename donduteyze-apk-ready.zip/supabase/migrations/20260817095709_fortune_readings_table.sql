/*
# Fortune Readings Table

1. New Tables
- `fortune_readings`: Stores user fortune readings with status tracking.
  - `id` (uuid, primary key)
  - `user_email` (text, not null — identifies the user, works for both anon and authenticated)
  - `fortune_type` (text, not null — 'coffee', 'tarot', 'palm', 'face', 'dream', 'katina', 'dice', 'wheel', 'lottery')
  - `status` (text, not null, default 'pending' — 'pending' = waiting 5 min, 'completed' = result ready, 'rejected' = invalid image)
  - `result` (text, nullable — the fortune reading text, null until completed)
  - `image_data` (text, nullable — base64 of uploaded photo(s), stored for reference)
  - `user_input` (text, nullable — for dream text or card picks)
  - `created_at` (timestamptz, default now())
  - `ready_at` (timestamptz — when the 5-min delay expires and result becomes visible)

2. Security
- Enable RLS on `fortune_readings`.
- anon + authenticated can read their own rows by user_email.
- anon + authenticated can insert their own rows.
- anon + authenticated can update their own rows (for status updates).
- anon + authenticated can delete their own rows.

3. Notes
- Uses user_email (stored in localStorage) as the user identifier since the app supports both anon and authenticated users.
- The 5-minute delay is managed client-side: `ready_at` = `created_at` + 5 minutes.
- The edge function writes the result directly to this table.
*/

CREATE TABLE IF NOT EXISTS fortune_readings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_email text NOT NULL,
  fortune_type text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  result text,
  image_data text,
  user_input text,
  created_at timestamptz DEFAULT now(),
  ready_at timestamptz DEFAULT (now() + interval '5 minutes')
);

ALTER TABLE fortune_readings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_readings" ON fortune_readings;
CREATE POLICY "select_own_readings" ON fortune_readings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_readings" ON fortune_readings;
CREATE POLICY "insert_own_readings" ON fortune_readings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_own_readings" ON fortune_readings;
CREATE POLICY "update_own_readings" ON fortune_readings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_own_readings" ON fortune_readings;
CREATE POLICY "delete_own_readings" ON fortune_readings FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_fortune_readings_user_email ON fortune_readings(user_email);
CREATE INDEX IF NOT EXISTS idx_fortune_readings_created_at ON fortune_readings(created_at DESC);