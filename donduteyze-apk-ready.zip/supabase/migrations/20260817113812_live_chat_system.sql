/*
# Canlı Falcı Sohbeti Sistemi

1. New Tables
- `live_chat_sessions`: Satın alınan canlı sohbet oturumları. Durumları: pending (admin bekleniyor), active (sohbet açık), ended (sonlanmış).
  - user_id (uuid, auth.users'a referans), user_email (text), status (text), price (numeric), purchased_at, connected_at, ended_at
- `live_chat_messages`: Oturuma ait mesajlar. sender: 'user' | 'admin'.
  - session_id (uuid, live_chat_sessions'a referans), sender (text), message (text), read (boolean), created_at
2. Security
- RLS etkin. Kullanıcılar kendi oturum ve mesajlarını görebilir/yazabilir.
- Admin (service role) tüm oturumlara erişebilir.
- Oturum status güncellemesi sadece admin (service role) tarafından yapılabilir; kullanıcılar insert/select/update(message read) yapabilir.
3. Important Notes
- Kullanıcı sadece kendi oturumunu görebilir (auth.uid() = user_id).
- Mesaj gönderme: kullanıcı sadece 'active' durumundaki oturuma mesaj gönderebilir (WITH CHECK ile).
- Admin bağlanana kadar kullanıcı mesaj gönderemez.
*/

CREATE TABLE IF NOT EXISTS live_chat_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  user_email text,
  status text NOT NULL DEFAULT 'pending',
  price numeric NOT NULL DEFAULT 99.99,
  purchased_at timestamptz DEFAULT now(),
  connected_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE live_chat_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_sessions" ON live_chat_sessions;
CREATE POLICY "select_own_sessions" ON live_chat_sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_sessions" ON live_chat_sessions;
CREATE POLICY "insert_own_sessions" ON live_chat_sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_sessions" ON live_chat_sessions;
CREATE POLICY "update_own_sessions" ON live_chat_sessions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS live_chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES live_chat_sessions(id) ON DELETE CASCADE,
  sender text NOT NULL DEFAULT 'user',
  message text NOT NULL,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE live_chat_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_messages" ON live_chat_messages;
CREATE POLICY "select_own_messages" ON live_chat_messages FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM live_chat_sessions WHERE live_chat_sessions.id = live_chat_messages.session_id AND live_chat_sessions.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_messages" ON live_chat_messages;
CREATE POLICY "insert_own_messages" ON live_chat_messages FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM live_chat_sessions WHERE live_chat_sessions.id = live_chat_messages.session_id AND live_chat_sessions.user_id = auth.uid() AND live_chat_sessions.status = 'active')
  );

DROP POLICY IF EXISTS "update_own_messages" ON live_chat_messages;
CREATE POLICY "update_own_messages" ON live_chat_messages FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM live_chat_sessions WHERE live_chat_sessions.id = live_chat_messages.session_id AND live_chat_sessions.user_id = auth.uid())
  );

CREATE INDEX IF NOT EXISTS idx_live_chat_sessions_user ON live_chat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_live_chat_sessions_status ON live_chat_sessions(status);
CREATE INDEX IF NOT EXISTS idx_live_chat_messages_session ON live_chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_live_chat_messages_created ON live_chat_messages(created_at);
