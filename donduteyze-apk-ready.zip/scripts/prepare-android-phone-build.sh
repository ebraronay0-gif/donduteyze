#!/bin/bash
set -euo pipefail

ANDROID_DIR="android"
APP_GRADLE="$ANDROID_DIR/app/build.gradle"
MANIFEST="$ANDROID_DIR/app/src/main/AndroidManifest.xml"

# Keep this conservative: Capacitor's generated project remains the source of truth.
# Only apply values when the generated files exist.
if [ -f "$APP_GRADLE" ]; then
  # Ensure modern Android SDK defaults for current phones; Capacitor 6 supports these values.
  sed -i -E 's/minSdkVersion[[:space:]]+[0-9]+/minSdkVersion 23/' "$APP_GRADLE" || true
fi

if [ -f "$MANIFEST" ]; then
  # No cleartext HTTP by default; do not weaken Android network security.
  true
fi
