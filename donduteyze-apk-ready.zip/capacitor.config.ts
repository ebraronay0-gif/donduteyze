import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.donduteyze.app',
  appName: 'Döndü Teyze',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
    backgroundColor: '#0a0a14',
  },
  plugins: {
    AdMob: {
      appID: 'ca-app-pub-3256954236969541~2502692179',
      initialize: true,
    },
  },
};

export default config;
