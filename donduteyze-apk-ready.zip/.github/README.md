# Döndü Teyze

Döndü Teyze is a fortune-telling web app built with React, Vite, TypeScript, TailwindCSS, and Supabase.
